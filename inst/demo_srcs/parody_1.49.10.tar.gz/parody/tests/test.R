library(parody)
library(testthat)

test_check("parody")

